/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package po3part3;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class Po3part3 {
private static ArrayList<String> developers = new ArrayList<>();
    private static ArrayList<String> taskNames = new ArrayList<>();
    private static ArrayList<String> taskIDs = new ArrayList<>();
    private static ArrayList<Integer> taskDurations = new ArrayList<>();
    private static ArrayList<String> taskStatuses = new ArrayList<>();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Initial Test Data
        addTask("Mike Smith", "Create Login", "ID1", 5, "To Do");
        addTask("Edward Harrison", "Create Add Features", "ID2", 8, "Doing");
        addTask("Samantha Paulson", "Create Reports", "ID3", 2, "Done");
        addTask("Glenda Oberholzer", "Add Arrays", "ID4", 11, "To Do");

        boolean running = true;
        while (running) {
            String[] options = {
                "Display tasks with status 'Done'",
                "Display task with longest duration",
                "Search for task by name",
                "Search tasks by developer",
                "Delete task by name",
                "Display full task report",
                "Exit"
            };
            String choice = (String) JOptionPane.showInputDialog(
                null,
                "Choose an action",
                "Task Manager",
                JOptionPane.PLAIN_MESSAGE,
                null,
                options,
                options[0]
            );

 if (choice == null || choice.equals("Exit")) {
                running = false;
            } else {
                switch (choice) {
                    case "Display tasks with status 'Done'":
                        displayTasksWithStatus("Done");
                        break;
                    case "Display task with longest duration":
                        displayTaskWithLongestDuration();
                        break;
                    case "Search for task by name":
                        String taskName = JOptionPane.showInputDialog("Enter the task name:");
                        if (taskName != null) {
                            searchTaskByName(taskName);
                        }
                        break;
                    case "Search tasks by developer":
                        String developer = JOptionPane.showInputDialog("Enter the developer's name:");
                        if (developer != null) {
                            searchTasksByDeveloper(developer);
                        }
                        break;
                    case "Delete task by name":
                        String taskNameToDelete = JOptionPane.showInputDialog("Enter the task name to delete:");
                        if (taskNameToDelete != null) {
                            deleteTaskByName(taskNameToDelete);
                        }
 break;
                    case "Display full task report":
                        displayTaskReport();
                        break;
                }
            }
        }
    }

    public static void addTask(String developer, String taskName, String taskID, int taskDuration, String taskStatus) {
        developers.add(developer);
        taskNames.add(taskName);
        taskIDs.add(taskID);
        taskDurations.add(taskDuration);
        taskStatuses.add(taskStatus);
    }

    public static void displayTasksWithStatus(String status) {
        StringBuilder result = new StringBuilder("Tasks with status \"" + status + "\":\n");
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskStatuses.get(i).equalsIgnoreCase(status)) {
                result.append("Developer: ").append(developers.get(i))
                      .append(", Task Name: ").append(taskNames.get(i))
                      .append(", Task Duration: ").append(taskDurations.get(i)).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, result.toString());
    }

    public static void displayTaskWithLongestDuration() {
        int maxDurationIndex = 0;
        for (int i = 1; i < taskDurations.size(); i++) {
if (taskDurations.get(i) > taskDurations.get(maxDurationIndex)) {
                maxDurationIndex = i;
            }
        }
        String result = "Task with longest duration: Developer: " + developers.get(maxDurationIndex) +
                        ", Duration: " + taskDurations.get(maxDurationIndex);
        JOptionPane.showMessageDialog(null, result);
    }

    public static void searchTaskByName(String taskName) {
        StringBuilder result = new StringBuilder("Search for task by name \"" + taskName + "\":\n");
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(taskName)) {
                result.append("Task Name: ").append(taskNames.get(i))
                      .append(", Developer: ").append(developers.get(i))
                      .append(", Task Status: ").append(taskStatuses.get(i));
                JOptionPane.showMessageDialog(null, result.toString());
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found.");
    }

    public static void searchTasksByDeveloper(String developer) {
        StringBuilder result = new StringBuilder("Tasks assigned to developer \"" + developer + "\":\n");
        for (int i = 0; i < taskNames.size(); i++) {
            if (developers.get(i).equalsIgnoreCase(developer)) {
                result.append("Task Name: ").append(taskNames.get(i))
                      .append(", Task Status: ").append(taskStatuses.get(i)).append("\n");
            }
        }
 JOptionPane.showMessageDialog(null, result.toString());
    }

    public static void deleteTaskByName(String taskName) {
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(taskName)) {
                developers.remove(i);
                taskNames.remove(i);
                taskIDs.remove(i);
                taskDurations.remove(i);
                taskStatuses.remove(i);
                JOptionPane.showMessageDialog(null, "Task \"" + taskName + "\" successfully deleted.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found.");
    }

    public static void displayTaskReport() {
        StringBuilder result = new StringBuilder("Task Report:\n");
        for (int i = 0; i < taskNames.size(); i++) {
            result.append("Developer: ").append(developers.get(i))
                  .append(", Task Name: ").append(taskNames.get(i))
                  .append(", Task ID: ").append(taskIDs.get(i))
                  .append(", Task Duration: ").append(taskDurations.get(i))
                  .append(", Task Status: ").append(taskStatuses.get(i)).append("\n");
        }
        JOptionPane.showMessageDialog(null, result.toString());
}
}
    
    

